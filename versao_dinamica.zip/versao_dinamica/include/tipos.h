#ifndef TIPOS_H
#define TIPOS_H

#define MAX_CODIGO 10
#define MAX_NOME 255
#define MAX_TIPO 255
#define MAX_HORARIO 255
#define MAX_LINHA 512

#endif