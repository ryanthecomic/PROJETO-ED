#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../include/materia_ppc.h"
#include "../include/aluno.h"
#include "../include/oferta.h"

int main() {
    MateriaPPC *listaMaterias = criarEstruturaPPC();
    Aluno *aluno = lerHistorico();

    // Obtém nome do aluno (simulado - implementar leitura real)
    char nome_aluno[100] = "Isaque B Cerqueira";

    OfertaDisciplinas *oferta = criarOfertaDisciplinas(20);
    GradeHoraria grade;
    inicializarGrade(&grade);

    // Adiciona matérias do PPC à oferta
    for (MateriaPPC *m = listaMaterias; m != NULL; m = m->Proxima) {
        adicionarDisciplinaOfertada(oferta, m);
    }

    preencherGrade(&grade, oferta);

    // Menu interativo
    int option = -1;
    while(true) {
        printf("\n=== SISTEMA DE ACONSELHAMENTO DE MATRÍCULA ===\n");
        printf("Aluno: %s\n", nome_aluno);
        printf("1 - Mostrar grade horária do aluno\n");
        printf("2 - Mostrar disciplinas sugeridas\n");
        printf("3 - Mostrar histórico\n");
        printf("4 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &option);

        switch(option) {
        case 1:
            mostrarGrade(&grade);
            break;
        case 2:
            printf("\nDisciplinas sugeridas:\n");
            for(int i = 0; i < oferta->quantidade; i++) {
                printf("- %s (Carga: %dh)\n", oferta->disciplinas[i].codigo,
                       oferta->disciplinas[i].carga_horaria);
            }
            printf("Carga horária total: %dh\n",
                   calcularCargaHorariaTotal(oferta));
            break;
        case 3:
            imprimirHistorico(aluno);
            break;
        case 4:
            liberarMaterias(listaMaterias);
            liberarAluno(aluno);
            liberarOfertaDisciplinas(oferta);
            exit(0);
        default:
            printf("Opção inválida!\n");
        }
    }
}