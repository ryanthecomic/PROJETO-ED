#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../include/oferta.h"

// Tabela de pesos das letras
int peso_letra(char letra) {
    switch(tolower(letra)) {
    case 'q': return 1; case 'w': return 6; case 'e': return 7;
    case 'r': return 6; case 't': return 5; case 'y': return 2;
    case 'u': return 3; case 'i': return 8; case 'o': return 9;
    case 'p': return 4; case 'a': return 2; case 's': return 5;
    case 'd': return 8; case 'f': return 7; case 'g': return 4;
    case 'h': return 1; case 'j': return 4; case 'k': return 7;
    case 'l': return 8; case 'z': return 3; case 'x': return 4;
    case 'c': return 9; case 'v': return 8; case 'b': return 3;
    case 'n': return 2; case 'm': return 5;
        // Caracteres acentuados (infelizmente usando valores ASCII estendidos)
    case 0xE1: return 3; // á
    case 0xE3: return 4; // ã
    case 0xE7: return 5; // ç
    case 0xE9: return 2; // é
    case 0xED: return 3; // í
    case 0xF3: return 6; // ó
    case 0xF5: return 7; // õ
    case 0xF4: return 6; // ô
    case 0xE2: return 1; // â
    case 0xEA: return 2; // ê
    default: return 0;
    }
}

OfertaDisciplinas* criarOfertaDisciplinas(int capacidade) {
    OfertaDisciplinas *oferta = malloc(sizeof(OfertaDisciplinas));
    if (!oferta) return NULL;

    oferta->disciplinas = malloc(capacidade * sizeof(DisciplinaOfertada));
    if (!oferta->disciplinas) {
        free(oferta);
        return NULL;
    }

    oferta->quantidade = 0;
    oferta->capacidade = capacidade;
    return oferta;
}

void liberarOfertaDisciplinas(OfertaDisciplinas *oferta) {
    if (oferta) {
        free(oferta->disciplinas);
        free(oferta);
    }
}

void inicializarGrade(GradeHoraria *grade) {
    for (int dia = 0; dia < DIAS_SEMANA; dia++) {
        for (int horario = 0; horario < HORARIOS_DIA; horario++) {
            strcpy(grade->grade[dia][horario].codigo_disciplina, "---");
        }
    }
}

void preencherGrade(GradeHoraria *grade, OfertaDisciplinas *oferta) {
    if (!grade || !oferta) return;

    for (int i = 0; i < oferta->quantidade; i++) {
        char horarios_copia[MAX_HORARIO];
        strcpy(horarios_copia, oferta->disciplinas[i].horarios);

        char *token = strtok(horarios_copia, ";");
        while (token) {
            int dia, periodo;
            parseHorario(token, &dia, &periodo);

            if (dia >= 0 && dia < DIAS_SEMANA && periodo >= 0 && periodo < HORARIOS_DIA) {
                strcpy(grade->grade[dia][periodo].codigo_disciplina,
                      oferta->disciplinas[i].codigo);
            }
            token = strtok(NULL, ";");
        }
    }
}

void mostrarGrade(GradeHoraria *grade) {
    if (!grade) return;

    const char *dias[] = {"Seg", "Ter", "Qua", "Qui", "Sex"};
    int hora_atual = 7, minuto_atual = 30;

    printf("\n=== GRADE HORÁRIA ===\n");
    printf("Hora   ");
    for (int i = 0; i < DIAS_SEMANA; i++) printf("%-6s", dias[i]);
    printf("\n");

    for (int horario = 0; horario < HORARIOS_DIA; horario++) {
        printf("%02d:%02d  ", hora_atual, minuto_atual);

        for (int dia = 0; dia < DIAS_SEMANA; dia++) {
            printf("%-6s", grade->grade[dia][horario].codigo_disciplina);
        }

        minuto_atual += 50;
        if (minuto_atual >= 60) {
            minuto_atual -= 60;
            hora_atual++;
        }
        printf("\n");
    }
}

void adicionarDisciplinaOfertada(OfertaDisciplinas *oferta, MateriaPPC *materia) {
    if (!oferta || !materia || oferta->quantidade >= oferta->capacidade) return;

    // Concatena todos os horários em uma string
    char horarios_combinados[MAX_HORARIO] = "";
    HorariosMateriaPPC *horario_atual = materia->Horarios;

    while (horario_atual) {
        if (horarios_combinados[0] != '\0') {
            strcat(horarios_combinados, ";");
        }
        strcat(horarios_combinados, horario_atual->Horario);
        horario_atual = horario_atual->Proxima;
    }

    // Adiciona à oferta
    strcpy(oferta->disciplinas[oferta->quantidade].codigo, materia->Codigo);
    strcpy(oferta->disciplinas[oferta->quantidade].horarios, horarios_combinados);
    oferta->disciplinas[oferta->quantidade].periodo = materia->Periodo;
    oferta->disciplinas[oferta->quantidade].carga_horaria = materia->CargaHorariaTotal;
    oferta->quantidade++;
}

int calcularPesoNome(const char *nome) {
    int peso = 0;
    for(int i = 0; nome[i] != '\0'; i++) {
        peso += peso_letra(nome[i]);
    }
    return peso;
}

int calcularCargaHorariaTotal(OfertaDisciplinas *oferta) {
    int carga_total = 0;
    for(int i = 0; i < oferta->quantidade; i++) {
        carga_total += oferta->disciplinas[i].carga_horaria;
    }
    return carga_total;
}

void parseHorario(const char *horario_str, int *dia, int *periodo) {
    // Formato: "24T34" -> dia 2 (terça), periodo 3
    *dia = horario_str[0] - '0' - 1;     // 0-4 (Seg=0)
    *periodo = horario_str[2] - '0' - 1;  // 0-16
}

int verificarPreRequisitos(const char *codigo, Aluno *aluno, MateriaPPC *ppc) {
    // Encontra a matéria no PPC
    MateriaPPC *materia = NULL;
    for(MateriaPPC *m = ppc; m != NULL; m = m->Proxima) {
        if(strcmp(m->Codigo, codigo) == 0) {
            materia = m;
            break;
        }
    }
    if(!materia) return 0;

    // Verifica se tem requisitos
    if(!materia->Requisitos || strcmp(materia->Requisitos->Codigo, "Nenhum") == 0) {
        return 1;
    }

    // Verifica se o aluno cumpriu todos os requisitos
    RequisitosMateriaPPC *req = materia->Requisitos;
    while(req != NULL) {
        int cumpriu = 0;
        MateriaCursada *cursada = aluno->Materias;
        while(cursada != NULL) {
            if(strcmp(cursada->Codigo, req->Codigo) == 0 && cursada->Nota >= 5.0) {
                cumpriu = 1;
                break;
            }
            cursada = cursada->Proxima;
        }
        if(!cumpriu) return 0;
        req = req->Proxima;
    }
    return 1;
}

int verificarChoqueHorario(GradeHoraria *grade, const char *horarios) {
    // Fazemos uma cópia para não modificar a string original
    char horarios_copia[MAX_HORARIO];
    strcpy(horarios_copia, horarios);

    char *token = strtok(horarios_copia, ";");
    while(token != NULL) {
        int dia, periodo;
        parseHorario(token, &dia, &periodo);

        if(dia >= 0 && dia < DIAS_SEMANA && periodo >= 0 && periodo < HORARIOS_DIA) {
            if(strcmp(grade->grade[dia][periodo].codigo_disciplina, "---") != 0) {
                return 1; // Choque detectado
            }
        }
        token = strtok(NULL, ";");
    }
    return 0; // Sem choque
}

void gerarOfertaPersonalizada(const char *nome_completo, MateriaPPC *ppc, Aluno *aluno, OfertaDisciplinas *oferta) {
    // Separa os nomes
    char nome_copia[100];
    strcpy(nome_copia, nome_completo);

    char nomes[10][50];
    int num_nomes = 0;
    char *token = strtok(nome_copia, " ");

    while(token != NULL && num_nomes < 10) {
        strcpy(nomes[num_nomes++], token);
        token = strtok(NULL, " ");
    }

    // Calcula parâmetros baseados no nome
    int peso_primeiro = calcularPesoNome(nomes[0]);
    int max_disciplinas = (peso_primeiro % 3 == 0) ? 10 : (peso_primeiro % 3 == 1) ? 8 : 6;

    int peso_segundo = (num_nomes > 1) ? calcularPesoNome(nomes[1]) : calcularPesoNome(nomes[0]);
    int estrategia_conclusao = peso_segundo % 3;

    int peso_terceiro = (num_nomes > 2) ? calcularPesoNome(nomes[2]) : calcularPesoNome(nomes[0]);
    int estrategia_enfase = peso_terceiro % 3;

    int peso_quarto = (num_nomes > 3) ? calcularPesoNome(nomes[3]) : calcularPesoNome(nomes[0]);
    int estrategia_distribuicao = peso_quarto % 3;

    // Gera oferta personalizada
    GradeHoraria grade_temp;
    inicializarGrade(&grade_temp);

    int carga_total = 0;
    int disciplinas_adicionadas = 0;

    // Ordena as matérias por período (dependendo da estratégia de conclusão)
    MateriaPPC *ordenadas[100];
    int count = 0;
    for(MateriaPPC *m = ppc; m != NULL; m = m->Proxima) {
        ordenadas[count++] = m;
    }

    // Ordenação simples (implementar algoritmo melhor se necessário)
    for(int i = 0; i < count-1; i++) {
        for(int j = i+1; j < count; j++) {
            if((estrategia_conclusao == 0 && ordenadas[i]->Periodo > ordenadas[j]->Periodo) ||
               (estrategia_conclusao == 1 && ordenadas[i]->Periodo < ordenadas[j]->Periodo)) {
                MateriaPPC *temp = ordenadas[i];
                ordenadas[i] = ordenadas[j];
                ordenadas[j] = temp;
            }
        }
    }

    // Adiciona disciplinas seguindo as regras
    for(int i = 0; i < count && disciplinas_adicionadas < max_disciplinas; i++) {
        MateriaPPC *m = ordenadas[i];

        // Verifica pré-requisitos
        if(!verificarPreRequisitos(m->Codigo, aluno, ppc)) continue;

        // Verifica choque de horário
        if(verificarChoqueHorario(&grade_temp, m->Horarios->Horario)) continue;

        // Verifica carga horária
        if(carga_total + m->CargaHorariaTotal > MAX_CARGA) continue;

        // Adiciona à oferta
        DisciplinaOfertada nova;
        strcpy(nova.codigo, m->Codigo);
        strcpy(nova.horarios, m->Horarios->Horario);
        nova.periodo = m->Periodo;
        nova.carga_horaria = m->CargaHorariaTotal;

        oferta->disciplinas[oferta->quantidade++] = nova;
        carga_total += m->CargaHorariaTotal;
        disciplinas_adicionadas++;

        // Atualiza grade temporária
        preencherGrade(&grade_temp, oferta);
    }

    // Garante pelo menos 1 disciplina
    if(oferta->quantidade == 0 && count > 0) {
        // Adiciona a primeira disciplina possível
        for(int i = 0; i < count; i++) {
            MateriaPPC *m = ordenadas[i];
            if(verificarPreRequisitos(m->Codigo, aluno, ppc)) {
                DisciplinaOfertada nova;
                strcpy(nova.codigo, m->Codigo);
                strcpy(nova.horarios, m->Horarios->Horario);
                nova.periodo = m->Periodo;
                nova.carga_horaria = m->CargaHorariaTotal;

                oferta->disciplinas[oferta->quantidade++] = nova;
                break;
            }
        }
    }
}